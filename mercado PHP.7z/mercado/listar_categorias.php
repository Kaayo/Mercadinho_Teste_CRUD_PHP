﻿<html>
<head>
	<title>LISTAR CATEGORIAS</title>
	<link rel="stylesheet" type="text/css" href="css/mercado.css">
</head>
<body>
<!-- HTML -->
	<a href="mercadinho.php"><input type="button" value="Voltar ao Menu Principal" class="botao3"/></a>
	<!--<fieldset> -->
			<!-- PHP -->
			<?php //1 
	
			//Faz a requisição de comandos ou elementos do arquivo 'db.php'
			require("db.php");
	
			//Realiza SQL -> Seleciona todos os Produtos Cadastrados no Banco
			$query = 'SELECT * FROM categorias ORDER BY cod_categoria ASC';

			//Variável recebe a Conexão da variável '$con' e o '$query'(SQL)
			//$result armazena os Dados retornados do SQL
			$result = mysqli_query($con, $query);	

			//Variável '$row' recebe o 'SQL' armazenado em um Array (mysqli_fetch_array)
			//Loop While é executado até listar todos os registros presentes na variável '$row' 
			?> <!-- //1 -->
			
			<div class="CSSTableGenerator">	
				<table >
					<th>ID</th>
 					<th>PRODUTO</th>
 					<th colspan="2">OPÇÕES</th>
			
			<?php //2
			while ($row = mysqli_fetch_array($result))

				{ //inicia loop while				
			?> <!-- //2 -->		

			<!-- HTML -->	
					<tr align="center">
						<td><?php echo $row['cod_categoria']; ?></td>
						<td><?php echo $row['nome_categoria']; ?></td>

						<td><a href="editar_categorias.php?edit=1&id=<?php echo $row['cod_categoria']; ?>"><input type="button" value="EDITAR" class="botao4"/></a></td>
						<td><a href="editar_categorias.php?delet=1&id=<?php echo $row['cod_categoria']; ?>&nome=<?php echo $row['nome_categoria']; ?>"><input type="button" value="DELETAR" class="botao4"/></a></td>
					</tr>
			

		<!-- PHP -->		
		<?php //3
			}// Fim While 
			
		?> <!-- //3 -->		
		</table>
	</div>
	<!-- </fieldset> -->
</body>
</html>


