<html>
<head>
	<title>LISTAR PRODUTOS</title>

	<!-- CSS -->
	<link rel="stylesheet" type="text/css" href="css/mercado.css">
</head>
<body>

<!-- HTML -->
<form method="post">
	<a href="mercadinho.php"><input type="button" value="Voltar ao Menu Principal" class="botao3"/></a>
	<!--<fieldset> -->
			<!-- PHP -->
			<?php //1 
	
			//Faz a requisição de comandos ou elementos do arquivo 'db.php' e 'editar_produtos.php'
			require("db.php");
			//require("editar_produtos.php");
	
			//Realiza SQL -> Seleciona todos os Produtos Cadastrados no Banco
			$query = 'SELECT * FROM produtos ORDER BY cod_produto ASC';

			//Variável recebe a Conexão da variável '$con' e o '$query'(SQL)
			//$result armazena os Dados retornados do SQL
			$result = mysqli_query($con, $query);	

			//Variável '$row' recebe o 'SQL' armazenado em um Array (mysqli_fetch_array)
			//Loop While é executado até listar todos os registros presentes na variável '$row' 
			?> <!-- //1 -->
			
			<div class="CSSTableGenerator">		
				<table >
					<th>ID</th>
 					<th>PRODUTO</th>
 					<th colspan="2">OPÇÕES</th>
				<?php //2
				while ($row = mysqli_fetch_array($result)) //Loop while onde variável '$row' recebe um 'Array' da variável '$result' (que retorna a conexão do banco ($con) e o sql ($query))

				{ //inicia loop while				
				
				?> <!-- //2 -->		

				<!-- HTML -->	
					<tr align="center">
						<td><?php echo $row['cod_produto']; ?></td> <!-- Exibe o código do produto na tabela // listar-->
						<td><?php echo $row['nome_produto']; ?></td> <!-- Exibe o nome do produto na tabela // listar -->

						<td><a href="editar_produtos.php?edit=1&id=<?php echo $row['cod_produto']; ?>"><input type="button" value="EDITAR" class="botao4"></a></td> <!-- Link redireciona para página 'editar_produtos.php' e variável 'id' recebe o código do produto selecionado -->
						
						<td><a href="editar_produtos.php?delet=1&id=<?php echo $row['cod_produto']; ?>&nome=<?php echo $row['nome_produto']; ?>"><input type="button" value="DELETAR" class="botao4"></a></td> <!-- Link redireciona para página 'editar_produtos.php' e variável 'id' recebe o código do produto e variável 'nome' recebe o nome do produto selecionado-->
					</tr>																				
					

			<!-- PHP -->		
				<?php //3
				
				}// Fim While 
			
				?> <!-- //3 -->		
		</table>
	</div>
	<!-- </fieldset> -->
	</form>
</body>
</html>


