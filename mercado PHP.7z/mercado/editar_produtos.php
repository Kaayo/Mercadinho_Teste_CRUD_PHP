<html>
<head>
	<title>EDITAR PRODUTOS</title>
	<link rel="stylesheet" type="text/css" href="css/mercado.css">
</head>
<body>
		
	<!-- HTML -->	
	<form> 
 		<a href="listar_produtos.php"><input type="button" value="VOLTAR MENU ANTERIOR"/ class="botao3"></a> <!-- Botão redireciona o link para a página 'listar_produtos.php' -->
 	</form> 

 		<!-- PHP -->
		<?php	
			include("db.php"); //inclui funcionalidades PHP de outra página PHP (neste caso, 'db.php')
			
			if (isset($_GET['edit'])) { //se a variável 'edit' que retorna como 'get' na URL receber receber algo e for setada, faça...
					
					  $sql = 'SELECT * FROM produtos WHERE cod_produto ='.$_GET['id']; //selecione tudo na tabela 'produtos' onde o código do produto é igual a variável "id" que recebe o código do produto selecionado durante o 'get' na URL
					  $query1 = mysqli_query($con, $sql); //Executa o sql
					  $row1 = mysqli_fetch_array($query1);

					  //var_dump($row1);

				echo '<form>
        				<fieldset class="campo" style="width:30%;">
        					<div class="botaoListProd">
        						<input type="text" 	 name="editar_nome_produto" value="'.$row1['nome_produto'].'" class="campoMaior">
        						<input type="hidden" name="antigo_nome_produto" value="'.$row1['nome_produto'].'"> 
        						<input type="hidden" name="codProduto" value="'.$row1['cod_produto'].'">
        						<input type="hidden" name="action" value="EditarProduto"> 
        						<input type="submit" name="button_editar_nome_produto" value="Alterar Nome Produto" class="botao3"> 
        						<input type="hidden" name="token" id="token" value="<?php sha1($id."hgjytr%7643@77676766778") ?>
        					</div>
        				</fieldset>
					</form>';
			} elseif(isset($_GET['action']) AND $_GET['action'] == 'EditarProduto') {

				if (trim($_GET['editar_nome_produto'] == '')) {
  					echo 'Preencha o Campo!';
  				} else {

  					if ($_GET['antigo_nome_produto'] == $_GET['editar_nome_produto']) { //caso o usuário tente editar uma categoria com o mesmo nome, faça...
  						echo 'valor já existe'; //exiba mensage que o valor já existe
  					} else {
  						$sql1 = 'UPDATE produtos SET nome_produto = "'.$_GET['editar_nome_produto'].'" WHERE cod_produto = '.$_GET['codProduto']; //senão realize o sql de inserção do novo nome da categoria através da concatenação das variáveis 'editar_nome_categoria' onde o código seja igual a variável 'codcategoria' 
  						$exibe2 = mysqli_query($con, $sql1); //efetua o sql acima
  						//$exibe = mysqli_query($con, $sql1); //variável recebe as variávies $con (banco de dados) e $sql1 (sql)
  							echo 'Edição Feita com Sucesso!';//.$exibe; //exibe mensagem de alteração do nome da categoria foi feita com sucesso, álém de exibir o que há de armazenado na variável 'exibe'
  					}
				}
			} 

			if (isset($_GET['delet'])) {
			
				$sql = 'DELETE FROM produtos WHERE cod_produto ='.$_GET['id'];
				$query1 = mysqli_query($con, $sql);
				
				echo 'Produto '.$_GET['nome'].' deletado com Sucesso!';

			}
		?>

</body>
</html>