<html>
<head>
	<title> CADASTRO DE ESTOQUE </title>
    <link rel="stylesheet" type="text/css" href="css/mercado.css">
</head>
<body>
	<form> 
 		<a href="mercadinho.php"><input type="button" value="Voltar ao Menu Principal"/ class="botao3"></a> <!-- Botão redireciona o link para a página 'listar_produtos.php' -->
 	</form> 

 	<!-- PHP - Banco de Dados -->
 	<?php
    	
    	#chama o arquivo de configuração com o banco
    	require ("db.php");
    	
 		#seleciona os dados da tabela produtos
    	$sql1 = 'SELECT * FROM produtos'; //selecione tudo na tabela 'produtos' onde o código do produto é igual a variável "id" que recebe o código do produto selecionado durante o 'get' na URL
		$resultado1 = mysqli_query($con, $sql1) or die ("ERRO: ".mysqli_error($con)); //Executa o sql  	
    
		#seleciona os dados da tabela categorias
        $sql2 = 'SELECT * FROM categorias'; //selecione tudo na tabela 'produtos' onde o código do produto é igual a variável "id" que recebe o código do produto selecionado durante o 'get' na URL
		$resultado2 = mysqli_query($con, $sql2) or die ("ERRO: ".mysqli_error($con)); //Executa o sql
    
      //$sql4 = 'SELECT * FROM estoques';
        $sql4 = 'SELECT cat.nome_categoria NOMECAT, prod.nome_produto NOMEPRO, est.valor_produto
                        FROM estoques est, categorias cat, produtos prod
                        WHERE est.cod_categoria1 = cat.cod_categoria
                        AND est.cod_produto1 = prod.cod_produto';

        $resultado3 = mysqli_query($con, $sql4) or die ("ERRO: ".mysqli_error($con));
    ?>

    <!-- abaixo montamos um formulário em html -->
   	<!-- e preenchemos o select com dados -->
     <form name="estoque_CadastraEstoque" method="get" action=""> <!-- Iniciando formulário -->
    	  <fieldset class="centralizaFieldset">
                <label for=""> PRODUTO </label>
                   <select name="ProdutosCombo"> <!-- Iniciando combobox -->
    		          <option CssCombobox>Selecione um Produto</option>

    			      <?php while($Prod = mysqli_fetch_array($resultado1)) { ?> <!-- While para preencher o combobox com os nomes dos produtos cadastrados no banco -->
    			      <option value="<?php echo $Prod['cod_produto'] ?>"><?php echo $Prod['nome_produto'] ?></option> 
    			      <?php } ?>
    		       </select> <!-- Finalizando combobox -->

                <label for=""> CATEGORIAS </label>
    		       <select name="CategoriasCombo"> <!-- Iniciando combobox -->
    			     <option>Selecione uma Categoria</option>

    			     <?php while($Catego = mysqli_fetch_array($resultado2)) { ?> <!-- While para preencher o combobox com os nomes das categorias cadastradas no banco -->
    			     <option value="<?php echo $Catego['cod_categoria'] ?>"><?php echo $Catego['nome_categoria'] ?></option>
    			     <?php } ?>
    		       </select> <!-- Finalizando combobox -->
     

                <label for=""> PREÇO </label>	
    		      <input type="text" name="precoEstoque" value=""> <!-- Campo para Inserir Preço do Produto durante o cadastro do estoque -->
    		      <input type="submit" name="botao_cadastrarEstoque" value="Cadastrar" class="botao4"> <!-- Botão para Efetuar o Cadastro do Estoque -->
    	          <input type="submit" name="botao_cadastrarEstoque" value="Listar" class="botao4"> <!-- Botão para Efetuar o Cadastro do Estoque -->
            </fieldset>
        </form>	
    		
            <?php /*Iniciando PHP*/

                if (isset($_GET['botao_cadastrarEstoque'])) { //Caso o botão para Cadastrar Estoque seja pressionado faça...
                    
                    switch ($_GET['botao_cadastrarEstoque']) {
                         case 'Cadastrar':  
                            
                            $idCATEGORIA = $_GET['CategoriasCombo']; //variável recebe o código da categoria proveniente do combobox durante o 'get'
                            $idPRODUTO = $_GET['ProdutosCombo']; //variável recebe o código do produto proveniente do combobox durante o 'get'
                            $precoESTOQUE = trim($_GET['precoEstoque']); //variável recebe algum valor proveniente do campo durante o 'get'(obs.: comando 'TRIM' no inicio para impedir o cadastro de espaçamento antes e depois o valor inserido no campo)
                   
                                //Condição - Caso as variáveis 'idCATEGORIA', 'idPRODUTO' e 'precoESTOQUE' esteja vazias faça...
                                if (($idCATEGORIA == 'Selecione um Produto') OR ($idPRODUTO == 'Selecione uma Categoria') OR  (trim($precoESTOQUE) == '')) {   
                                    echo 'Preencha Todos os Campos'; //mensagem para preencher todos os campos...
                                } else { //senão cadastre o Estoque
                                    $sql3 = 'INSERT INTO estoques (cod_produto1, cod_categoria1, valor_produto) VALUES ('.$idPRODUTO.','.$idCATEGORIA.','.$precoESTOQUE.')';
                                    $query = mysqli_query($con, $sql3);

                                    echo 'Estoque Cadastrado com Sucesso!'; //mensagem de cadastro OK!
                                }    
                         break;

                         case 'Listar':  ?>
                           
                        <div class="CSSTableGenerator">
                            <table border="1" cellspacing="2" cellpadding="3" align="top">
                                <th>CATEGORIA</th>
                                <th>PRODUTO</th>
                                <th colspan="4">OPÇÕES</th>
            
                                <!-- Listar Produtos Estocados na Tabela de Exibição -->
                                <?php while ($row = mysqli_fetch_array($resultado3)): ?>
                                    <tr align="center">
                                   
                                        <td><?php echo $row['NOMEPRO']; ?></td>
                                        <td><?php echo $row['NOMECAT']; ?></td>

                                        <td><a href="editar_categorias.php?edit=1&id=<?php echo $row['cod_categoria']; ?>"><input type="button" value="EDITAR"/></a></td>
                                        <td><a href="editar_categorias.php?delet=1&id=<?php echo $row['cod_categoria']; ?>&nome=<?php echo $row['nome_categoria']; ?>"><input type="button" value="DELETAR"/></a></td>
                                </tr>  
                               </div>       
                        <?php endwhile ?>


                       <?php  break; //case (switch)

                } //fim switch
            }  //fim if   
    		?> 
             <!-- Finalizando PHP -->            
</body>
</html>