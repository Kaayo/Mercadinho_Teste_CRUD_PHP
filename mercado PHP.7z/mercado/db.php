<?php
	//mysql vs mysqli -> mysqli é mais recente, utilize sempre comandos recentes!
	//Realiza Conexão com o Banco
	$con = mysqli_connect("localhost","root","", "dbmercado");// ip, usuário, senha e banco de dados
	
		//Verifica se há erro na conexão
		if (mysqli_connect_errno()) {
			die('Erro ao Conectar ao MySQL: '.mysqli_connect_error());
		} //else {
?>
