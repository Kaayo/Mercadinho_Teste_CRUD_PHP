<html>
<head>
	<title>EDITAR categoriaS</title>
	<link rel="stylesheet" type="text/css" href="css/mercado.css">
</head>
<body>
		
	<form> 
 		<a href="listar_categorias.php"><input type="button" value="VOLTAR MENU ANTERIOR"/ class="botao3"></a><!-- Botão com link para redirecionar a página para outro arquivo (tela) -->
 	</form> 

		<!-- PHP -->
		<?php	

			include("db.php"); //realiza a inclusão de outro arquivo PHP neste arquivo (neste caso está fazendo a inclusão do arquivo PHP referente ao banco de dados)
			
			if (isset($_GET['edit'])) { //Condição - Se durante o evento 'get' (URL do navegador) a variável 'edit' for setada, faça...
					
					  $sql = 'SELECT * FROM categorias WHERE cod_categoria ='.$_GET['id']; //realizada a consulta sql com uma condição através da concatenação da variável 'id' (variável recebe o valor na URL durante o 'get')
					  $query1 = mysqli_query($con, $sql); //Executa o sql
					  $row1 = mysqli_fetch_array($query1); // variável recebe a consulta sql através de um Array

				//Declarando semântica HTML dentro do PHP
				echo '<form>
        				<fieldset class="campo" style="width:30%;">
        					<div class="botaoListCat">
        						<input type="text" name="editar_nome_categoria" value="'.$row1['nome_categoria'].'" class="campoMaior">  
        						<input type="hidden" name="antigo_nome_categoria" value="'.$row1['nome_categoria'].'">  
        						<input type="hidden" name="codcategoria" value="'.$row1['cod_categoria'].'"> 
        						<input type="hidden" name="action" value="Editarcategoria">
        						<input type="submit" name="button_editar_nome_categoria" value="Altera Nome categoria" class="botao3"> 
        					<div>
        				</fieldset>
					</form>';

			} elseif(isset($_GET['action']) AND $_GET['action'] == "Editarcategoria") { //Condição - se input retornar o name 'action' e seu valor vor igual a 'Editarcategoria', faça...
  				
  				if (trim($_GET['editar_nome_categoria'] == '')) {
  					echo 'Preencha o Campo!';
  				} else {

  					if ($_GET['antigo_nome_categoria'] == $_GET['editar_nome_categoria']) { //caso o usuário tente editar uma categoria com o mesmo nome, faça...
  						echo 'valor já existe'; //exiba mensage que o valor já existe
  					} else {
  						$sql1 = 'UPDATE categorias SET nome_categoria = "'.$_GET['editar_nome_categoria'].'" WHERE cod_categoria = '.$_GET['codcategoria']; //senão realize o sql de inserção do novo nome da categoria através da concatenação das variáveis 'editar_nome_categoria' onde o código seja igual a variável 'codcategoria'
  						$exibe = mysqli_query($con, $sql1); //variável recebe as variávies $con (banco de dados) e $sql1 (sql)
  							echo 'Edição Feita com Sucesso!'.$exibe; //exibe mensagem de alteração do nome da categoria foi feita com sucesso, álém de exibir o que há de armazenado na variável 'exibe'
  					}
				}
			} 

			if (isset($_GET['delet'])) { //Condição - Se durante o evento 'get' (URL do navegador) a variável 'delet' for setada, faça...
			
				$sql = 'DELETE FROM categorias WHERE cod_categoria ='.$_GET['id']; //realize o sql de exclusão da categoria onde o código provenha através da variável concatenada 'id'
				$query1 = mysqli_query($con, $sql); //executa o sql
				echo 'categoria '.$_GET['nome'].' deletado com Sucesso!'; //exibe mensagem de exclusão de categoria realizada com sucesso

			}
		?> <!-- FIM PHP -->
</body>
</html>

<!-- var_dump(variável) - serve para informar detalhes de uma variável, array, object, etc-->