<?php //Inicio PHP
	
	require("db.php"); //requisitando funcionalidades de outro arquivo PHP (neste caso está requisitando o arquivo PHP do banco de dados)

	//Verifica se recebe dados (input oculto)
	if (isset($_POST['action'])) { //verifica se o botao de cadastrar foi clicado durante o 'post'...
		switch ($_POST['action']) { //caso durante o 'post' o nome do input hidden (escondido) seja igual a 'action' faça...
			case 'cadastrarProduto': //Condição - caso o valor (atributo 'value') do input hidden seja igual a 'cadastrarProduto' faça...
				$cadProduto = $_POST['campo_cad_produto']; //variável recebe o 
				
				if (trim($_POST['campo_cad_produto']) == '') {
					echo 'Preencha o Campo!';
				} else {
					$query = 'INSERT INTO produtos(nome_produto) VALUES ("'.$cadProduto.'")'; //realizao o sql de inserção do registro do campo no banco de dados através da concatenação com uma variável 
					$_POST = null; //limpa 'post'
						
					//echo $query;	
						if (!mysqli_query($con, $query)) { //caso houver erro durante a conexão com o banco de dados...
							echo 'Erro: '.mysqli_error($con); //exibe mensagem de erro informando o tipo do erro...
						} else {
							echo ' Produto Cadastrado com Sucesso!'; //exibe mensagem de sucesso durante o cadastro do produto
						} 
					}
					break; //finaliza o laço switch (case)
					
			case 'cadastrarCategoria': //Condição - caso o valor (atributo 'value') do input hidden seja igual a 'cadastrarCategoria' faça...
				$cadCategoria = $_POST['campo_cad_categoria']; //variável recebe o valor inserido no campo durante o 'post'
				
				if (trim($_POST['campo_cad_categoria']) == '') {
					echo 'Preencha o Campo!';
				} else {
					$query = 'INSERT INTO categorias(nome_categoria) VALUES ("'.$cadCategoria.'")'; //realizao o sql de inserção do registro do campo no banco de dados através da concatenação com uma variável 
					$_POST = null; //limpa 'post'
								
						if (!mysqli_query($con, $query)) { //Condição - senão houver problema na conexão com o banco de dados e nem com o sql faça...
							echo 'Erro: '.mysqli_error($con); //Caso houver erro exibirá mensagem de erro e informando o tipo do erro
						} else {
							echo ' Categoria Cadastrada com Sucesso!'; //caso ocorra tudo certo, exiba mensagem de Categoria cadastrada com sucesso
						}
					}
					break; //finaliza o laço switch (case)
				}//fim switch
			}//
	
?><!-- Fim PHP -->
<!-- HTML -->
<!DOCTYPE html>
<html lang="pt-br"> <!-- informa que o navegador deverá executar o html exibindo informações em português Brasil -->
<head>
	<meta charset="UTF-8">
	<title>Exemplo de Conexão PHP com Banco de Dados MySQL</title> <!-- Título HTML (aparece na aba do navegador) -->

	<!-- CSS -->
	<link rel="stylesheet" type="text/css" href="css/mercado.css">
</head>
<body>
	<div class="titulo"><img src="imagens/faixa3.png" class="tituloImagem"><br/><div id="tituloMain"><h4>ATIVIDADE PHP - CRUD (Inserção, Exclusão, Edição & Listagem de Dados) </h4></div></div> <!-- Título da página -->


    <!-- Criação de Formulário HTML-->
   <div id="DivMain">
      <fieldset class="centro1"> <!-- Comprimento do Fieldset (não ficar do comprimento da página inteira) -->
    	<h2><div><img src="imagens/produtos1.png" class="imagem">PRODUTOS</div></h2>
    		<form  method="post"><!-- Enviandos dados pelo método post-->
    			<div id="botaoListProd">	
    				<input type="text" name="campo_cad_produto" value="" class="campo"><!-- Campo para Digitar Disciplina\ vaida apenas letras, numeros não-->
    				<input type="hidden" name="action" value="cadastrarProduto"><!-- Campo Oculto recebe um valor pelo durante o "post", conforme o valor enviado será executado tal tipo de código-->
    				<input type="submit" value="cadastrar" class="botao1">
    					<form> 
 							<a href="listar_produtos.php"><input type="button" value="Listar Produtos" class="botao1"/></a> 	 							
 						</form>
 				</div>		 
    		</form>
	   </fieldset>


	   <fieldset class="centro2">
    	<h2><div><img src="imagens/categoria1.jpg" class="imagem">CATEGORIAS</div></h2>
    		<form  method="post"><!-- Enviandos dados pelo método post-->
    			<div id="botaoListCat">
    				<input type="text" name="campo_cad_categoria" value="" class="campo"><!-- Atributo 'pattern' (pattern="[a-z,A-Z\s]+$) - valida apenas letras, numeros não-->
    				<input type="hidden" name="action" value="cadastrarCategoria"><!-- Campo Oculto recebe um valor pelo durante o "post", conforme o valor enviado será executado tal tipo de código-->
    				<input type="submit" value="cadastrar" class="botao1"><!-- Envia as informações durante o 'post' da página -->
    					<form> 			
 							<a href="listar_categorias.php"><input type="button" value="Listar Categorias" class="botao1"/></a> <!-- Botão com link para redirecionar a página para outro arquivo (tela) -->
 						</form> 
 				</div>
    		</form>
	   </fieldset>

	   <fieldset class="centro3">
		<h2><div><img src="imagens/estoque1.png" class="imagem1">ESTOQUE</div></h2>
    		<form method="post">
    			<div>
 					<a href="cadastrar_estoque.php"><input type="button" value="Cadastrar Estoque" class="botao2"/></a> 
 				</div>
 			</form>	
	   </fieldset>
	</div>
</body>
</html>


<!-- Observação -->

<!-- 
validar se campo não está vazio (branco) -> 'empty', '', max_lenght, min_lenght, strl
elimina espaços em branco em um campo antes e depois de um valor/string -> 'trim' trim(str)





 -->

